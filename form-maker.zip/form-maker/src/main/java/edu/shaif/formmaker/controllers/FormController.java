package edu.shaif.formmaker.controllers;
import edu.shaif.formmaker.models.Field;
import edu.shaif.formmaker.models.Form;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

import edu.shaif.formmaker.services.FormService;


@RestController

public class FormController {


    @Autowired
    private FormService formService;


    @GetMapping("/forms/")
    public List<Form> getAllForms(){
       return formService.getAllForms();
    }

    @PostMapping("/forms/")
    public Form createForm(@RequestBody Form form){
        return formService.addForm(form);
    }

    @GetMapping("/forms/{id}")
    public ResponseEntity<Form> getFormById(@PathVariable Long id) {
        Form form = formService.getFormById(id);
        if (form != null){
            return ResponseEntity.ok(form);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/forms/{id}")
    public ResponseEntity<Form> updateForm(@PathVariable Long id, @RequestBody Map<String, String> updatedData){
        Form currentForm = formService.getFormById(id);
        if (currentForm != null){
            String newName = updatedData.get("name");
            if (newName != null && !newName.isEmpty()) {
                currentForm.setName(newName);
            }
            Form savedForm = formService.addForm(currentForm);
            return ResponseEntity.ok(savedForm);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/forms/{id}")
    public ResponseEntity<Void> deleteForm(@PathVariable Long id){
        formService.deleteForm(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/forms/{id}/fields")
    public ResponseEntity<List<Field>> getFieldsByFormId(@PathVariable Long id) {
        Form form = formService.getFormById(id);
        if (form != null) {
            return ResponseEntity.ok(formService.getFieldsByFormId(id));
        }
        return ResponseEntity.notFound().build();
    }

    @PutMapping("/forms/{id}/fields")
    public ResponseEntity<Form> updateFieldsByFormId(@PathVariable Long id, @RequestBody List<Field> updatedFields) {
        Form form = formService.getFormById(id);
        if (form != null) {
            return ResponseEntity.ok(formService.updateFieldsByFormId(id, updatedFields));
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/forms/{id}/publish")
    public ResponseEntity<Form> changePublishStatus(@PathVariable Long id) {
        Form form = formService.getFormById(id);
        if (form != null) {
            return ResponseEntity.ok(formService.changePublishStatus(id));
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/forms/published")
    public List<Form> getPublishedForms() {
        return formService.getPublishedForms();
    }
}
