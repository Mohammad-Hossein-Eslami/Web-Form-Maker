package edu.shaif.formmaker.services;
import edu.shaif.formmaker.models.Field;
import edu.shaif.formmaker.models.Form;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


import edu.shaif.formmaker.repository.FormRepository;

@Service
public class FormService {

    @Autowired
    private FormRepository formRepository;

    public List<Form> getAllForms(){
        return formRepository.findAll();
    }

    public Form addForm(Form form){
        return formRepository.save(form);
    }

    public Form getFormById(Long id){
        List<Form> forms = formRepository.findAll();
        for (Form form : forms) {
            if (form.getId() == id) {
                return form;
            }
        }
        return null;
    }

    public void deleteForm(Long id){
        formRepository.deleteById(id);
    }

    public List<Field> getFieldsByFormId(Long id){
        Form form = getFormById(id);
        if (form != null){
            return form.getFields();
        } else
            return null;
    }

    public Form updateFieldsByFormId(Long id, List<Field> updatedFields){
        Form form = getFormById(id);
        if (form != null) {
            form.getFields().clear();
            form.getFields().addAll(updatedFields);
            return formRepository.save(form);
        }
        return null;
    }

    public Form changePublishStatus(Long id){
        Form form = getFormById(id);
        if (form != null){
            form.setReleaseStatus(!form.isReleaseStatus());
            return formRepository.save(form);
        }
        return null;
    }

    public List<Form> getPublishedForms() {
        return formRepository.findByReleaseStatus(true);
    }
}
