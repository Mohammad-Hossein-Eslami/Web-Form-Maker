package edu.shaif.formmaker.repository;


import edu.shaif.formmaker.models.Form;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FormRepository extends JpaRepository<Form, Long> {
    List<Form> findByReleaseStatus(boolean releaseStatus);
}