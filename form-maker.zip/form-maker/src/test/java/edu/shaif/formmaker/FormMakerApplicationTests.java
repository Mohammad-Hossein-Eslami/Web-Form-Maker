package edu.shaif.formmaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormMakerApplicationTests {

    @Test
    void contextLoads() {
    }

}
